"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import Header from "../components/Header";
import MiniFooter from "../components/MiniFooter";
import { featuredProjects } from "../data/projects";

const PROJECTS_PER_PAGE = 5;

function useProjectLayoutMode() {
  const [mode, setMode] = useState<"mobile" | "desktop" | null>(null);

  useEffect(() => {
    const resolveMode = () => {
      const desktopWidth = window.matchMedia("(min-width: 1024px)").matches;
      const finePointer = window.matchMedia("(pointer: fine)").matches;
      const hoverAvailable = window.matchMedia("(hover: hover)").matches;
      const coarsePointer = window.matchMedia("(pointer: coarse)").matches;

      const shouldUseDesktop =
        desktopWidth && finePointer && hoverAvailable && !coarsePointer;

      setMode(shouldUseDesktop ? "desktop" : "mobile");
    };

    resolveMode();

    window.addEventListener("resize", resolveMode);
    window.addEventListener("orientationchange", resolveMode);

    return () => {
      window.removeEventListener("resize", resolveMode);
      window.removeEventListener("orientationchange", resolveMode);
    };
  }, []);

  return mode;
}

function Pagination({
  currentPage,
  totalPages,
  onChange,
  className = "",
}: {
  currentPage: number;
  totalPages: number;
  onChange: (page: number) => void;
  className?: string;
}) {
  if (totalPages <= 1) {
    return null;
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {Array.from({ length: totalPages }).map((_, index) => {
        const page = index + 1;
        const isActive = currentPage === page;

        return (
          <button
            key={page}
            type="button"
            onClick={() => onChange(page)}
            className={`h-8 w-8 border text-[11px] transition ${
              isActive
                ? "border-[#4A433D] bg-[#4A433D] text-[#F3F0EB]"
                : "border-neutral-300 text-neutral-500 hover:border-[#4A433D] hover:text-[#4A433D]"
            }`}
            aria-label={`Go to project page ${page}`}
          >
            {page}
          </button>
        );
      })}
    </div>
  );
}

function MobileProjects() {
  const [currentPage, setCurrentPage] = useState(1);

  const projects = featuredProjects;
  const totalPages = Math.ceil(projects.length / PROJECTS_PER_PAGE);

  const pagedProjects = useMemo(() => {
    const startIndex = (currentPage - 1) * PROJECTS_PER_PAGE;
    const endIndex = startIndex + PROJECTS_PER_PAGE;

    return projects.slice(startIndex, endIndex);
  }, [projects, currentPage]);

  return (
    <main className="bg-[#F3F0EB] text-[#4A433D] min-h-screen flex flex-col">
      <Header />

      <section className="flex-1 max-w-7xl mx-auto w-full px-6 pt-24 pb-10">
        <div className="mb-7">
          <p className="uppercase tracking-[0.35em] text-[10px] text-neutral-500 mb-2">
            Projects
          </p>

          <h1 className="text-3xl font-light leading-none">Selected Works</h1>
        </div>

        <div className="grid grid-cols-2 gap-x-4 gap-y-8">
          {pagedProjects.map((project, index) => (
            <Link
              key={project.slug}
              href={`/projects/${project.slug}`}
              className="group block"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-[#d8d1ca] mb-3">
                <Image
                  src={project.heroImage}
                  alt={project.title}
                  fill
                  priority={currentPage === 1 && index < 2}
                  quality={68}
                  sizes="50vw"
                  className="object-cover"
                />

                <div className="absolute inset-0 bg-black/10" />

                <div className="absolute left-3 top-3 right-3 flex justify-between text-white/75 text-[8px] tracking-[0.22em] uppercase">
                  <span>{project.projectGroup}</span>
                  <span>{project.year}</span>
                </div>
              </div>

              <p className="text-[9px] uppercase tracking-[0.22em] text-neutral-500 mb-1">
                {project.type}
              </p>

              <h2 className="text-[13px] font-light leading-[1.35] break-keep">
                {project.title}
              </h2>

              <p className="text-[11px] text-neutral-500 mt-1">
                {project.area}
              </p>
            </Link>
          ))}
        </div>

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onChange={(page) => {
            setCurrentPage(page);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          className="justify-center mt-10"
        />

        <div className="mt-10 flex justify-between text-[9px] text-neutral-500 tracking-[0.25em] uppercase">
          <span>Portfolio</span>
          <span>
            Page {currentPage} / {totalPages}
          </span>
        </div>
      </section>

      <MiniFooter />
    </main>
  );
}

function DesktopProjects() {
  const [currentPage, setCurrentPage] = useState(1);
  const [activeIndex, setActiveIndex] = useState(0);
  const pausedRef = useRef(false);

  const projects = featuredProjects;
  const totalPages = Math.ceil(projects.length / PROJECTS_PER_PAGE);

  const pagedProjects = useMemo(() => {
    const startIndex = (currentPage - 1) * PROJECTS_PER_PAGE;
    const endIndex = startIndex + PROJECTS_PER_PAGE;

    return projects.slice(startIndex, endIndex);
  }, [projects, currentPage]);

  const active = pagedProjects[activeIndex];

  useEffect(() => {
    setActiveIndex(0);
  }, [currentPage]);

  useEffect(() => {
    if (pagedProjects.length <= 1) return;

    const timer = setInterval(() => {
      if (pausedRef.current) return;

      setActiveIndex((prev) => (prev + 1) % pagedProjects.length);
    }, 3000);

    return () => clearInterval(timer);
  }, [pagedProjects.length]);

  if (!active) {
    return null;
  }

  return (
    <main className="bg-[#F3F0EB] text-[#4A433D] h-screen overflow-hidden flex flex-col">
      <Header />

      <section
        onMouseEnter={() => {
          pausedRef.current = true;
        }}
        onMouseLeave={() => {
          pausedRef.current = false;
        }}
        className="flex-1 min-h-0 max-w-7xl mx-auto w-full px-16 pt-28 pb-4"
      >
        <div className="grid grid-cols-[0.82fr_1.18fr] gap-16 h-full min-h-0">
          <div className="flex flex-col min-h-0 order-1">
            <div className="mb-6">
              <p className="uppercase tracking-[0.35em] text-xs text-neutral-500 mb-2">
                Projects
              </p>

              <h1 className="text-5xl font-light leading-none">
                Selected Works
              </h1>
            </div>

            <div className="flex-1 min-h-0">
              {pagedProjects.map((project, index) => {
                const isActive = activeIndex === index;
                const displayNumber =
                  (currentPage - 1) * PROJECTS_PER_PAGE + index + 1;

                return (
                  <Link
                    key={project.slug}
                    href={`/projects/${project.slug}`}
                    onMouseEnter={() => setActiveIndex(index)}
                    onFocus={() => setActiveIndex(index)}
                    className="group grid grid-cols-[42px_1fr_auto] gap-4 items-center border-b border-neutral-300 py-3"
                  >
                    <span
                      className={
                        isActive
                          ? "text-sm text-[#4A433D]"
                          : "text-sm text-neutral-400"
                      }
                    >
                      {String(displayNumber).padStart(2, "0")}
                    </span>

                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`block h-px transition-all duration-500 ${
                            isActive ? "w-7 bg-[#4A433D]" : "w-2 bg-neutral-300"
                          }`}
                        />

                        <h2
                          className={
                            isActive
                              ? "text-xl font-light translate-x-1 transition duration-500 break-keep"
                              : "text-xl font-light transition duration-500 group-hover:translate-x-1 break-keep"
                          }
                        >
                          {project.title}
                        </h2>
                      </div>

                      <p className="text-[10px] uppercase tracking-[0.22em] text-neutral-500 mt-1 ml-9">
                        {project.type}
                      </p>
                    </div>

                    <span
                      className={
                        isActive
                          ? "text-xs text-[#4A433D]"
                          : "text-xs text-neutral-400"
                      }
                    >
                      {project.year}
                    </span>
                  </Link>
                );
              })}
            </div>

            <div className="pt-5 flex items-center justify-between">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onChange={(page) => {
                  setCurrentPage(page);
                }}
              />

              <p className="text-[10px] text-neutral-500 tracking-[0.25em] uppercase">
                Page {currentPage} / {totalPages}
              </p>
            </div>
          </div>

          <div className="flex flex-col min-h-0 order-2">
            <Link
              href={`/projects/${active.slug}`}
              className="group relative flex-1 min-h-0 overflow-hidden bg-[#d8d1ca]"
            >
              <Image
                key={`${active.slug}-${active.heroImage}`}
                src={active.heroImage}
                alt={active.title}
                fill
                priority={currentPage === 1 && activeIndex === 0}
                quality={78}
                sizes="58vw"
                className="object-cover transition-transform duration-700 ease-in-out group-hover:scale-105"
              />

              <div className="absolute inset-0 bg-black/20" />

              <div className="absolute left-8 top-8 right-8 flex justify-between text-white/75 text-[11px] tracking-[0.25em] uppercase">
                <span>{active.projectGroup}</span>
                <span>{active.area}</span>
              </div>

              <div className="absolute left-8 bottom-8 text-white">
                <p className="uppercase tracking-[0.3em] text-[10px] mb-3 text-white/70">
                  Current Selection
                </p>

                <h3 className="text-4xl font-light mb-3 break-keep">
                  {active.title}
                </h3>

                <div className="flex gap-6 text-sm text-white/75">
                  <span>{active.type}</span>
                  <span>{active.year}</span>
                </div>
              </div>
            </Link>

            <div className="pt-3 flex justify-between text-xs text-neutral-500 tracking-[0.25em] uppercase">
              <span>Auto Preview</span>
              <span>Click to Open</span>
            </div>
          </div>
        </div>
      </section>

      <MiniFooter />
    </main>
  );
}

export default function ProjectsPage() {
  const mode = useProjectLayoutMode();

  if (mode === null) {
    return (
      <main className="bg-[#F3F0EB] text-[#4A433D] min-h-screen">
        <Header />
        <section className="max-w-7xl mx-auto w-full px-6 pt-24 pb-10">
          <p className="uppercase tracking-[0.35em] text-[10px] text-neutral-500 mb-2">
            Projects
          </p>
          <h1 className="text-3xl font-light leading-none">Selected Works</h1>
        </section>
      </main>
    );
  }

  if (mode === "desktop") {
    return <DesktopProjects />;
  }

  return <MobileProjects />;
}